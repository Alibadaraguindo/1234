from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'admin_app/home.html')

def page_teacher(request):
    return render(request,'admin_app/page_teacher.html')
