const liens = document.getElementsByName("lien");

/*function changerMain(a){
    for(i=0 ; i<3 ; i++){
        liens[i].style.backgroundColor = "red"
    }
    a.style.backgroundColor="blue"
}*/
