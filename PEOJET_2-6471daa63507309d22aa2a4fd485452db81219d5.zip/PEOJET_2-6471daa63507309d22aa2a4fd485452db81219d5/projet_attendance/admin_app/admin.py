from django.contrib import admin
from admin_app.models import Teacher 


# Register your models here.
admin.site.register(Teacher)
